Kotlin Anko Tutorial – Basics of Anko Layouts and More! – Android Library
https://resocoder.com/2018/03/09/kotlin-anko-tutorial-basics-of-anko-layouts-and-more-android-library/

RecyclerView Adapter with Anko
https://medium.com/@abduazizkayumov/recyclerview-adapter-with-anko-22418055cd05

How To Add RecyclerView Using Kotlin?
https://choicetechlab.com/blog/add-recyclerview-using-kotlin/